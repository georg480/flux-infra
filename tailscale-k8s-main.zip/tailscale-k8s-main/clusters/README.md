TODO:

- [X] ~add RenovateBot~
- [X] ~setup Tailscale~
